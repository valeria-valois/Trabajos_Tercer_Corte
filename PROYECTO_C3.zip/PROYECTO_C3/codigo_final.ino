#include "LedControl.h"

//SEMAFORO 1. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO1 = 22;
int AMARILLO1 = 23;
int VERDE1 = 24;
//SEMAFORO 2. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO2 = 25;
int AMARILLO2 = 26;
int VERDE2 = 27;
//SEMAFORO 3. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO3 = 28;
int AMARILLO3 = 29;
int VERDE3 = 30;
//SEMAFORO 4. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO4 = 31;
int AMARILLO4 = 32;
int VERDE4 = 33;
//SEMAFORO I. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOI = 34;
int AMARILLOI = 35;
int VERDEI = 36;
//SEMAFORO II. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOII = 37;
int AMARILLOII = 38;
int VERDEII = 39;
//SEMAFORO III. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOIII = 40;
int AMARILLOIII = 41;
int VERDEIII = 42;
//SEMAFORO VI. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOVI = 43;
int AMARILLOVI = 44;
int VERDEVI = 45;
//BOTON PEATONAL A
int BOTON_PA = A8;
//BOTON PEATONAL B
int BOTON_PB = A9;
//BOTON PEATONAL C
int BOTON_PC = A10;
//BOTON PEATONAL D
int BOTON_PD = A11;

//BUZZER PEATONAL A
int BUZZERA = 0;
//BUZZER PEATONAL B
int BUZZERB = 1;
//BUZZER PEATONAL C
int BUZZERC = 2;
//BUZZER PEATONAL D
int BUZZERD = 3;

// ======================= MATRIZ LED (cuenta regresiva peatonal) =======================
// Mismos pines que tu sketch de prueba (libres, no chocan con el resto del circuito)
int CLK = 11;
int DIN = 9;
int LOAD = 8;

LedControl lc = LedControl(9, 11, 8, 1);

byte cero[8]   = {B00011100,B00011100,B00001000,B00011100,B00101010,B00001000,B00011100,B00010100};
byte uno[8]    = {B00110000,B00110000,B00011100,B01111010,B00011000,B00100100,B00100010,B00100000};
byte dos[8]    = {B00110000,B00110000,B00011000,B00111000,B00011000,B00011000,B00011100,B00010000};
byte tres[8]   = {B00110000,B00110000,B00011000,B00011000,B00011000,B00011000,B00001000,B00001000};
byte cuatro[8] = {B00110000,B00110000,B00011000,B00011100,B00111100,B00111000,B00100100,B00000100};

// Secuencia de la matriz: 1,2,3,4,1,2,3,4 (rápido) y se queda fija en el muñeco "0"
byte* digitosCountdown[9] = { uno, dos, tres, cuatro, uno, dos, tres, cuatro, cero };
const int NUM_PASOS_COUNTDOWN = 9;

// Los primeros 8 pasos (1,2,3,4 x2) van rápido; el paso 9 (el muñeco) se queda
// fijo con el tiempo que sobra de la fase peatonal.
const int PASOS_RAPIDOS = 8;
const unsigned long DURACION_PASO_RAPIDO = 400; // ms por cada paso rápido (ajusta a tu gusto)

int pasoCountdownActual = -1; // -1 fuerza el primer dibujo al entrar en fase peatonal

void mostrarMatrix(byte numero[]) {
  for (int i = 0; i < 8; i++) {
    lc.setRow(0, i, numero[i]);
  }
}

// ======================= AGREGADO PARA EL CONTROL DE FASES =======================

// Arreglos para poder recorrer los 8 semáforos vehiculares con índices 0..7
// Orden: 0=Sem1, 1=Sem2, 2=Sem3, 3=Sem4, 4=SemI, 5=SemII, 6=SemIII, 7=SemVI
int vehRojo[8]   = {ROJO1, ROJO2, ROJO3, ROJO4, ROJOI, ROJOII, ROJOIII, ROJOVI};
int vehAmar[8]   = {AMARILLO1, AMARILLO2, AMARILLO3, AMARILLO4, AMARILLOI, AMARILLOII, AMARILLOIII, AMARILLOVI};
int vehVerde[8]  = {VERDE1, VERDE2, VERDE3, VERDE4, VERDEI, VERDEII, VERDEIII, VERDEVI};

// Buzzers de los 4 cruces peatonales (la matriz reemplaza a los LEDs rojo/verde peatonales)
int peBuzzer[4] = {BUZZERA, BUZZERB, BUZZERC, BUZZERD};

// Cada "par vehicular" que se enciende en las fases 2,4,6,8 (según tu especificación)
// parVerde[0] = FASE2 (Sem1 y Sem3) -> índices 0 y 2
// parVerde[1] = FASE4 (Sem2 y Sem4) -> índices 1 y 3
// parVerde[2] = FASE6 (SemI y SemVI) -> índices 4 y 7
// parVerde[3] = FASE8 (SemII y SemIII) -> índices 5 y 6
const int parVerde[4][2] = {
  {0, 2},
  {1, 3},
  {4, 7},
  {5, 6}
};

// Estados de la máquina de estados del ciclo
enum EstadoCiclo { PEATONAL, VERDE_VEH, AMARILLO_VEH };
EstadoCiclo estado = PEATONAL;

int indicePar = 0;              // cuál de los 4 pares vehiculares sigue (0..3)
unsigned long tiempoInicioFase = 0;

// Duraciones (ajusta a tu gusto, en milisegundos)
const unsigned long DURACION_PEATONAL = 6000;   // tiempo en verde para peatones
const unsigned long DURACION_VERDE_VEH = 6000;  // tiempo en verde para el par vehicular

// Duración del último paso (el muñeco): lo que sobra de la fase peatonal
// después de correr los pasos rápidos.
const unsigned long DURACION_PASO_FINAL = DURACION_PEATONAL - (DURACION_PASO_RAPIDO * PASOS_RAPIDOS);

// Control del parpadeo del amarillo (no bloqueante)
const unsigned long INTERVALO_AMARILLO = 300;   // cada cuánto cambia de estado el amarillo
const int PARPADEOS_AMARILLO = 5;               // cuántas veces parpadea (igual que tu código original)
int contadorParpadeo = 0;
bool amarilloEncendido = false;
unsigned long tiempoUltimoParpadeo = 0;

// ======================= FUNCIONES AUXILIARES =======================

void todoVehicularRojo() {
  for (int i = 0; i < 8; i++) {
    digitalWrite(vehRojo[i], HIGH);
    digitalWrite(vehAmar[i], LOW);
    digitalWrite(vehVerde[i], LOW);
  }
}

void peatonalesEnVerde() {
  for (int i = 0; i < 4; i++) {
    tone(peBuzzer[i], 2000); // suena mientras dura la fase peatonal
  }
  // Reinicia la cuenta regresiva en la matriz cada vez que entra la fase peatonal
  pasoCountdownActual = -1;
}

void peatonalesEnRojo() {
  for (int i = 0; i < 4; i++) {
    noTone(peBuzzer[i]); // se apaga al terminar la fase peatonal
  }
  // La matriz NO se apaga: se queda mostrando el muñeco ("0")
  // hasta que arranque la siguiente fase peatonal.
}

// Actualiza la matriz según cuánto tiempo lleva la fase peatonal (no bloqueante)
void actualizarCountdownMatrix(unsigned long transcurrido) {
  int paso;
  unsigned long finPasosRapidos = (unsigned long)DURACION_PASO_RAPIDO * PASOS_RAPIDOS;

  if (transcurrido < finPasosRapidos) {
    paso = transcurrido / DURACION_PASO_RAPIDO;       // recorre 1,2,3,4,1,2,3,4 rápido
  } else {
    paso = PASOS_RAPIDOS;                              // último paso: el muñeco ("0"), fijo
  }

  if (paso != pasoCountdownActual) {
    pasoCountdownActual = paso;
    mostrarMatrix(digitosCountdown[pasoCountdownActual]);
  }
}

// Enciende en verde el par vehicular indicado (idx dentro de parVerde), asumiendo que ya estaba en rojo
void encenderParVerde(int idxPar) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehRojo[a], LOW);
  digitalWrite(vehVerde[a], HIGH);
  digitalWrite(vehRojo[b], LOW);
  digitalWrite(vehVerde[b], HIGH);
}

// Apaga el verde del par vehicular indicado (deja ambos LED apagados, listo para amarillo)
void apagarVerdePar(int idxPar) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehVerde[a], LOW);
  digitalWrite(vehVerde[b], LOW);
}

void ponerRojoPar(int idxPar) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehAmar[a], LOW);
  digitalWrite(vehAmar[b], LOW);
  digitalWrite(vehRojo[a], HIGH);
  digitalWrite(vehRojo[b], HIGH);
}

void setAmarilloPar(int idxPar, bool encendido) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehAmar[a], encendido ? HIGH : LOW);
  digitalWrite(vehAmar[b], encendido ? HIGH : LOW);
}

// ======================= SETUP =======================

void setup() {
  pinMode(ROJO1, OUTPUT);
  pinMode(AMARILLO1, OUTPUT);
  pinMode(VERDE1, OUTPUT);
  pinMode(ROJO2, OUTPUT);
  pinMode(AMARILLO2, OUTPUT);
  pinMode(VERDE2, OUTPUT);
  pinMode(ROJO3, OUTPUT);
  pinMode(AMARILLO3, OUTPUT);
  pinMode(VERDE3, OUTPUT);
  pinMode(ROJO4, OUTPUT);
  pinMode(AMARILLO4, OUTPUT);
  pinMode(VERDE4, OUTPUT);
  pinMode(ROJOI, OUTPUT);
  pinMode(AMARILLOI, OUTPUT);
  pinMode(VERDEI, OUTPUT);
  pinMode(ROJOII, OUTPUT);
  pinMode(AMARILLOII, OUTPUT);
  pinMode(VERDEII, OUTPUT);
  pinMode(ROJOIII, OUTPUT);
  pinMode(AMARILLOIII, OUTPUT);
  pinMode(VERDEIII, OUTPUT);
  pinMode(ROJOVI, OUTPUT);
  pinMode(AMARILLOVI, OUTPUT);
  pinMode(VERDEVI, OUTPUT);
  pinMode(BOTON_PA, INPUT_PULLUP);//Botón para dar vía a peatones
  pinMode(BOTON_PB, INPUT_PULLUP);//Botón para dar vía a peatones
  pinMode(BOTON_PC, INPUT_PULLUP);//Botón para dar vía a peatones
  pinMode(BOTON_PD, INPUT_PULLUP);//Botón para dar vía a peatones

  pinMode(BUZZERA, OUTPUT);
  pinMode(BUZZERB, OUTPUT);
  pinMode(BUZZERC, OUTPUT);
  pinMode(BUZZERD, OUTPUT);

  // Inicialización de la matriz LED
  lc.shutdown(0, false);
  lc.setIntensity(0, 4);
  lc.clearDisplay(0);

  // Estado inicial: todo vehicular en rojo, arrancamos en fase peatonal
  todoVehicularRojo();
  peatonalesEnRojo();   // esto ya limpia la matriz por seguridad
  peatonalesEnVerde();  // esto reinicia pasoCountdownActual a -1
  estado = PEATONAL;
  tiempoInicioFase = millis();
}

// ======================= LOOP NO BLOQUEANTE =======================

void loop() {
  unsigned long ahora = millis();

  switch (estado) {

    case PEATONAL: {
      unsigned long transcurrido = ahora - tiempoInicioFase;

      // Actualiza la cuenta regresiva en la matriz mientras dura la fase peatonal
      actualizarCountdownMatrix(transcurrido);

      if (transcurrido >= DURACION_PEATONAL) {
        peatonalesEnRojo();
        encenderParVerde(indicePar);
        estado = VERDE_VEH;
        tiempoInicioFase = ahora;
      }
      break;
    }

    case VERDE_VEH:
      if (ahora - tiempoInicioFase >= DURACION_VERDE_VEH) {
        apagarVerdePar(indicePar);
        estado = AMARILLO_VEH;
        contadorParpadeo = 0;
        amarilloEncendido = false;
        tiempoUltimoParpadeo = ahora;
      }
      break;

    case AMARILLO_VEH:
      // Parpadeo no bloqueante del amarillo, cada INTERVALO_AMARILLO ms cambia de estado
      if (ahora - tiempoUltimoParpadeo >= INTERVALO_AMARILLO) {
        amarilloEncendido = !amarilloEncendido;
        setAmarilloPar(indicePar, amarilloEncendido);
        tiempoUltimoParpadeo = ahora;

        if (!amarilloEncendido) {
          // Se completó un parpadeo (encendido + apagado)
          contadorParpadeo++;
        }

        if (contadorParpadeo >= PARPADEOS_AMARILLO) {
          // Terminó el parpadeo: este par pasa a rojo
          ponerRojoPar(indicePar);

          // Avanzamos al siguiente par vehicular (0->1->2->3->0...)
          indicePar = (indicePar + 1) % 4;

          // Volvemos a la fase peatonal (esto reinicia la cuenta regresiva de la matriz)
          peatonalesEnVerde();
          estado = PEATONAL;
          tiempoInicioFase = ahora;
        }
      }
      break;
  }
}
