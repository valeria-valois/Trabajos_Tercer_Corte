/***************************************************************************
 * PROYECTO:
 * SEMÁFORO INTELIGENTE DE 4 VÍAS
 * Arduino Mega 2560
 * 8 Semáforos Vehiculares
 * 4 Semáforos Peatonales
 * 4 Matrices MAX7219
 * Botón Peatonal
 * Buzzer
 ***************************************************************************/

#include <LedControl.h>

//========================================================
// MAX7219
//========================================================

#define DIN_PIN   51
#define CLK_PIN   52
#define CS_PIN    53

// 4 módulos MAX7219
LedControl matriz = LedControl(DIN_PIN, CLK_PIN, CS_PIN, 4);

//========================================================
// SEMÁFOROS VEHICULARES
//========================================================

// S1
const byte S1R = 22;
const byte S1A = 23;
const byte S1V = 24;

// S2
const byte S2R = 25;
const byte S2A = 26;
const byte S2V = 27;

// S3
const byte S3R = 28;
const byte S3A = 29;
const byte S3V = 30;

// S4
const byte S4R = 31;
const byte S4A = 32;
const byte S4V = 33;

// S5
const byte S5R = 34;
const byte S5A = 35;
const byte S5V = 36;

// S6
const byte S6R = 37;
const byte S6A = 38;
const byte S6V = 39;

// S7
const byte S7R = 40;
const byte S7A = 41;
const byte S7V = 42;

// S8
const byte S8R = 43;
const byte S8A = 44;
const byte S8V = 45;

//========================================================
// SEMÁFOROS PEATONALES
//========================================================

const byte PR1 = 46;
const byte PV1 = 47;

const byte PR2 = 48;
const byte PV2 = 49;

const byte PR3 = A0;
const byte PV3 = A1;

const byte PR4 = A2;
const byte PV4 = A3;

//========================================================
// BOTÓN Y BUZZER
//========================================================

const byte BOTON = A4;
const byte BUZZER = A5;

//========================================================
// TIEMPOS
//========================================================

const int TIEMPO_VERDE = 15;
const int TIEMPO_AMARILLO = 3;
const int TIEMPO_ROJO = 2;
const int TIEMPO_PEATON = 10;

//========================================================
// VARIABLES
//========================================================

bool solicitudPeaton = false;

int contador = 0;
void setup()
{

//==================================
// Configurar MAX7219
//==================================

for(int i=0;i<4;i++)
{
    matriz.shutdown(i,false);
    matriz.setIntensity(i,8);
    matriz.clearDisplay(i);
}

//==================================
// Semáforos Vehiculares
//==================================

for(int i=22;i<=45;i++)
{
    pinMode(i,OUTPUT);
}

//==================================
// Peatonales
//==================================

pinMode(PR1,OUTPUT);
pinMode(PV1,OUTPUT);

pinMode(PR2,OUTPUT);
pinMode(PV2,OUTPUT);

pinMode(PR3,OUTPUT);
pinMode(PV3,OUTPUT);

pinMode(PR4,OUTPUT);
pinMode(PV4,OUTPUT);

//==================================
// Botón
//==================================

pinMode(BOTON,INPUT_PULLUP);

//==================================
// Buzzer
//==================================

pinMode(BUZZER,OUTPUT);

digitalWrite(BUZZER,LOW);

//==================================
// Estado Inicial
//==================================

todosRojo();

peatonesRojo();

}
void todosRojo()
{

digitalWrite(S1R,HIGH);
digitalWrite(S2R,HIGH);
digitalWrite(S3R,HIGH);
digitalWrite(S4R,HIGH);
digitalWrite(S5R,HIGH);
digitalWrite(S6R,HIGH);
digitalWrite(S7R,HIGH);
digitalWrite(S8R,HIGH);

digitalWrite(S1A,LOW);
digitalWrite(S2A,LOW);
digitalWrite(S3A,LOW);
digitalWrite(S4A,LOW);
digitalWrite(S5A,LOW);
digitalWrite(S6A,LOW);
digitalWrite(S7A,LOW);
digitalWrite(S8A,LOW);

digitalWrite(S1V,LOW);
digitalWrite(S2V,LOW);
digitalWrite(S3V,LOW);
digitalWrite(S4V,LOW);
digitalWrite(S5V,LOW);
digitalWrite(S6V,LOW);
digitalWrite(S7V,LOW);
digitalWrite(S8V,LOW);

}

void peatonesRojo()
{

digitalWrite(PR1,HIGH);
digitalWrite(PR2,HIGH);
digitalWrite(PR3,HIGH);
digitalWrite(PR4,HIGH);

digitalWrite(PV1,LOW);
digitalWrite(PV2,LOW);
digitalWrite(PV3,LOW);
digitalWrite(PV4,LOW);

}

//========================================================
// APAGA TODOS LOS SEMÁFOROS
//========================================================

void apagarSemaforos()
{
  for (int i = 22; i <= 45; i++)
    digitalWrite(i, LOW);
}

void faseNorteSurVerde()
{
  todosRojo();

  delay(500);

  digitalWrite(S1R, LOW);
  digitalWrite(S5R, LOW);
  digitalWrite(S2R, LOW);
  digitalWrite(S7R, LOW);

  digitalWrite(S1V, HIGH);
  digitalWrite(S5V, HIGH);
  digitalWrite(S2V, HIGH);
  digitalWrite(S7V, HIGH);
}
void faseNorteSurAmarillo()
{

  digitalWrite(S1V, LOW);
  digitalWrite(S5V, LOW);
  digitalWrite(S2V, LOW);
  digitalWrite(S7V, LOW);

  digitalWrite(S1A, HIGH);
  digitalWrite(S5A, HIGH);
  digitalWrite(S2A, HIGH);
  digitalWrite(S7A, HIGH);

}
void faseEsteOesteVerde()
{

  todosRojo();

  delay(500);

  digitalWrite(S6R, LOW);
  digitalWrite(S4R, LOW);
  digitalWrite(S8R, LOW);

  digitalWrite(S6V, HIGH);
  digitalWrite(S4V, HIGH);
  digitalWrite(S8V, HIGH);

}
void faseEsteOesteAmarillo()
{

  digitalWrite(S6V, LOW);
  digitalWrite(S4V, LOW);
  digitalWrite(S8V, LOW);

  digitalWrite(S6A, HIGH);
  digitalWrite(S4A, HIGH);
  digitalWrite(S8A, HIGH);

}
void faseGiroProtegido()
{
    todosRojo();

    delay(500);

    // Aquí irán los giros
}

void peatonesVerde()
{
  digitalWrite(PR1, LOW);
  digitalWrite(PR2, LOW);
  digitalWrite(PR3, LOW);
  digitalWrite(PR4, LOW);

  digitalWrite(PV1, HIGH);
  digitalWrite(PV2, HIGH);
  digitalWrite(PV3, HIGH);
  digitalWrite(PV4, HIGH);
}

void loop()
{

}