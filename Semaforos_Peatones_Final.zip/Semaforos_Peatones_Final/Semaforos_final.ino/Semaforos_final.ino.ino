#include "LedControl.h"

//SEMAFORO 1. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO1 = 22;
int AMARILLO1 = 23;
int VERDE1 = 24;
//SEMAFORO 2. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO2 = 25;
int AMARILLO2 = 26;
int VERDE2 = 27;
//SEMAFORO 3. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO3 = 28;
int AMARILLO3 = 29;
int VERDE3 = 30;
//SEMAFORO 4. PARA SEGUIR DERECHO O CRUZAR A LA DERECHA
int ROJO4 = 31;
int AMARILLO4 = 32;
int VERDE4 = 33;
//SEMAFORO I. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOI = 34;
int AMARILLOI = 35;
int VERDEI = 36;
//SEMAFORO II. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOII = 37;
int AMARILLOII = 38;
int VERDEII = 39;
//SEMAFORO III. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOIII = 40;
int AMARILLOIII = 41;
int VERDEIII = 42;
//SEMAFORO VI. PARA PARA CRUZAR A LA IZQUIERDA
int ROJOVI = 43;
int AMARILLOVI = 44;
int VERDEVI = 45;
//BOTON PEATONAL A
int BOTON_PA = A8;
//BOTON PEATONAL B
int BOTON_PB = A9;
//BOTON PEATONAL C
int BOTON_PC = A10;
//BOTON PEATONAL D
int BOTON_PD = A11;

//BUZZER PEATONAL A
int BUZZERA = 0;
//BUZZER PEATONAL B
int BUZZERB = 1;
//BUZZER PEATONAL C
int BUZZERC = 2;
//BUZZER PEATONAL D
int BUZZERD = 3;

//LEDS PEATONALES (rojo/verde individuales por cruce)
int PE_ROJOa  = 46;
int PE_VERDEa = 47;
int PE_ROJOb  = 48;
int PE_VERDEb = 49;
int PE_ROJOc  = 50;
int PE_VERDEc = 51;
int PE_ROJOd  = 52;
int PE_VERDEd = 53;

int peVerde[4] = {PE_VERDEa, PE_VERDEb, PE_VERDEc, PE_VERDEd};
int peRojo[4]  = {PE_ROJOa,  PE_ROJOb,  PE_ROJOc,  PE_ROJOd};

// ======================= MATRIZ LED (cuenta regresiva peatonal) =======================
int CLK = 11;
int DIN = 9;
int LOAD = 8;

LedControl lc = LedControl(9, 11, 8, 1);

byte cero[8]   = {B00011100,B00011100,B00001000,B00011100,B00101010,B00001000,B00011100,B00010100};
byte uno[8]    = {B00110000,B00110000,B00011100,B01111010,B00011000,B00100100,B00100010,B00100000};
byte dos[8]    = {B00110000,B00110000,B00011000,B00111000,B00011000,B00011000,B00011100,B00010000};
byte tres[8]   = {B00110000,B00110000,B00011000,B00011000,B00011000,B00011000,B00001000,B00001000};
byte cuatro[8] = {B00110000,B00110000,B00011000,B00011100,B00111100,B00111000,B00100100,B00000100};

// Secuencia de la matriz: 1,2,3,4,1,2,3,4 (rápido) y se queda fija en el muñeco "0"
byte* digitosCountdown[9] = { uno, dos, tres, cuatro, uno, dos, tres, cuatro, cero };
const int NUM_PASOS_COUNTDOWN = 9;

const int PASOS_RAPIDOS = 8;
const unsigned long DURACION_PASO_RAPIDO = 400; // ms por cada paso rápido

int pasoCountdownActual = -1;

void mostrarMatrix(byte numero[]) {
  for (int i = 0; i < 8; i++) {
    lc.setRow(0, i, numero[i]);
  }
}

// ======================= AGREGADO PARA EL CONTROL DE FASES =======================

int vehRojo[8]   = {ROJO1, ROJO2, ROJO3, ROJO4, ROJOI, ROJOII, ROJOIII, ROJOVI};
int vehAmar[8]   = {AMARILLO1, AMARILLO2, AMARILLO3, AMARILLO4, AMARILLOI, AMARILLOII, AMARILLOIII, AMARILLOVI};
int vehVerde[8]  = {VERDE1, VERDE2, VERDE3, VERDE4, VERDEI, VERDEII, VERDEIII, VERDEVI};

int peBuzzer[4] = {BUZZERA, BUZZERB, BUZZERC, BUZZERD};

// parVerde[0] = FASE2 (Sem1 y Sem3) -> índices 0 y 2
// parVerde[1] = FASE4 (Sem2 y Sem4) -> índices 1 y 3
// parVerde[2] = FASE6 (SemI y SemVI) -> índices 4 y 7
// parVerde[3] = FASE8 (SemII y SemIII) -> índices 5 y 6
const int parVerde[4][2] = {
  {0, 2},
  {1, 3},
  {4, 7},
  {5, 6}
};

enum EstadoCiclo { PEATONAL, VERDE_VEH, AMARILLO_VEH };
EstadoCiclo estado = PEATONAL;

int indicePar = 0;
unsigned long tiempoInicioFase = 0;

// Duraciones (ajusta a tu gusto, en milisegundos)
const unsigned long DURACION_PEATONAL  = 6000;  // tiempo BASE de la fase peatonal
const unsigned long DURACION_VERDE_VEH = 6000;  // tiempo en verde para el par vehicular
const unsigned long DURACION_AMARILLO  = 3000;  // amarillo FIJO (ya no parpadea)

const unsigned long DURACION_PASO_FINAL = DURACION_PEATONAL - (DURACION_PASO_RAPIDO * PASOS_RAPIDOS);

// --- Control del buzzer peatonal: tono continuo + cuenta final 4,3,2,1 ---
// En los últimos 4 segundos de la fase peatonal, el tono continuo se apaga
// y en su lugar suena un beep corto por cada segundo restante (4,3,2,1).
const unsigned long DURACION_CUENTA_FINAL = 4000; // últimos 4s con beeps de cuenta regresiva
bool enCuentaFinalBuzzer = false;
int segundoBuzzerAnterior = -1;

// --- Botones peatonales: función de EXTENSIÓN de tiempo ---
// Mientras esté sonando el tono continuo (antes de que empiece la cuenta
// final 4,3,2,1), presionar cualquier botón agrega tiempo extra al cruce.
// duracionPeatonalActual es la duración "real" de la fase en este ciclo;
// arranca en DURACION_PEATONAL y puede crecer hasta DURACION_PEATONAL_MAX.
unsigned long duracionPeatonalActual = DURACION_PEATONAL;
const unsigned long DURACION_EXTENSION = 3000;      // tiempo que agrega cada pulsación
const unsigned long DURACION_PEATONAL_MAX = 12000;  // tope máximo (evita bloquear el tráfico)
bool botonAnteriorEstado = false; // para detectar flanco (que no sume varias veces la misma pulsación)

// Revisa los botones y extiende el tiempo peatonal si corresponde.
// Solo funciona ANTES de que arranque la cuenta final (4,3,2,1), para no
// romper la lógica de esa cuenta regresiva.
void revisarExtensionPeatonal(unsigned long transcurrido) {
  bool presionado = (digitalRead(BOTON_PA) == LOW) ||
                     (digitalRead(BOTON_PB) == LOW) ||
                     (digitalRead(BOTON_PC) == LOW) ||
                     (digitalRead(BOTON_PD) == LOW);

  // Solo se cuenta el flanco de "recién presionado" (evita sumar de más
  // mientras el peatón mantiene el botón apretado)
  if (presionado && !botonAnteriorEstado) {
    unsigned long umbralCuentaFinal = duracionPeatonalActual - DURACION_CUENTA_FINAL;
    bool aunNoEmpiezaCuentaFinal = (transcurrido < umbralCuentaFinal);

    if (aunNoEmpiezaCuentaFinal && (duracionPeatonalActual + DURACION_EXTENSION <= DURACION_PEATONAL_MAX)) {
      duracionPeatonalActual += DURACION_EXTENSION;
    }
  }
  botonAnteriorEstado = presionado;
}

// ======================= FUNCIONES AUXILIARES =======================

void todoVehicularRojo() {
  for (int i = 0; i < 8; i++) {
    digitalWrite(vehRojo[i], HIGH);
    digitalWrite(vehAmar[i], LOW);
    digitalWrite(vehVerde[i], LOW);
  }
}

void peatonalesEnVerde() {
  for (int i = 0; i < 4; i++) {
    digitalWrite(peVerde[i], HIGH);
    digitalWrite(peRojo[i], LOW);
    tone(peBuzzer[i], 2000); // tono continuo "piiiiiiii" mientras puede cruzar
  }
  pasoCountdownActual = -1;
  enCuentaFinalBuzzer = false;
  segundoBuzzerAnterior = -1;
  duracionPeatonalActual = DURACION_PEATONAL; // se reinicia la duración de este ciclo
  botonAnteriorEstado = false;
}

void peatonalesEnRojo() {
  for (int i = 0; i < 4; i++) {
    noTone(peBuzzer[i]);
    digitalWrite(peVerde[i], LOW);
    digitalWrite(peRojo[i], HIGH);
  }
}

// Actualiza la matriz según cuánto tiempo lleva la fase peatonal (no bloqueante)
void actualizarCountdownMatrix(unsigned long transcurrido) {
  int paso;
  unsigned long finPasosRapidos = (unsigned long)DURACION_PASO_RAPIDO * PASOS_RAPIDOS;

  if (transcurrido < finPasosRapidos) {
    paso = transcurrido / DURACION_PASO_RAPIDO;
  } else {
    paso = PASOS_RAPIDOS;
  }

  if (paso != pasoCountdownActual) {
    pasoCountdownActual = paso;
    mostrarMatrix(digitosCountdown[pasoCountdownActual]);
  }
}

// Controla el buzzer: tono continuo al inicio, y en los últimos 4 segundos
// (según duracionPeatonalActual, que puede haber crecido por extensión)
// cambia a beeps discretos que cuentan 4,3,2,1.
void actualizarBuzzerPeatonal(unsigned long transcurrido) {
  unsigned long umbral = duracionPeatonalActual - DURACION_CUENTA_FINAL;

  if (transcurrido < umbral) {
    // Aún en tono continuo, no hay que hacer nada más (ya suena desde peatonalesEnVerde())
    return;
  }

  // Entramos a la cuenta final: apaga el tono continuo la primera vez
  if (!enCuentaFinalBuzzer) {
    enCuentaFinalBuzzer = true;
    for (int i = 0; i < 4; i++) noTone(peBuzzer[i]);
  }

  unsigned long restante = duracionPeatonalActual - transcurrido;
  int segundo = (restante / 1000) + 1;   // 4,3,2,1
  if (segundo > 4) segundo = 4;
  if (segundo < 1) segundo = 1;

  if (segundo != segundoBuzzerAnterior) {
    segundoBuzzerAnterior = segundo;
    for (int i = 0; i < 4; i++) {
      tone(peBuzzer[i], 2200, 200); // beep corto por cada número (4,3,2,1)
    }
  }
}

void encenderParVerde(int idxPar) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehRojo[a], LOW);
  digitalWrite(vehVerde[a], HIGH);
  digitalWrite(vehRojo[b], LOW);
  digitalWrite(vehVerde[b], HIGH);
}

void apagarVerdePar(int idxPar) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehVerde[a], LOW);
  digitalWrite(vehVerde[b], LOW);
}

void ponerRojoPar(int idxPar) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehAmar[a], LOW);
  digitalWrite(vehAmar[b], LOW);
  digitalWrite(vehRojo[a], HIGH);
  digitalWrite(vehRojo[b], HIGH);
}

void setAmarilloPar(int idxPar, bool encendido) {
  int a = parVerde[idxPar][0];
  int b = parVerde[idxPar][1];
  digitalWrite(vehAmar[a], encendido ? HIGH : LOW);
  digitalWrite(vehAmar[b], encendido ? HIGH : LOW);
}

// ======================= SETUP =======================

void setup() {
  pinMode(ROJO1, OUTPUT);
  pinMode(AMARILLO1, OUTPUT);
  pinMode(VERDE1, OUTPUT);
  pinMode(ROJO2, OUTPUT);
  pinMode(AMARILLO2, OUTPUT);
  pinMode(VERDE2, OUTPUT);
  pinMode(ROJO3, OUTPUT);
  pinMode(AMARILLO3, OUTPUT);
  pinMode(VERDE3, OUTPUT);
  pinMode(ROJO4, OUTPUT);
  pinMode(AMARILLO4, OUTPUT);
  pinMode(VERDE4, OUTPUT);
  pinMode(ROJOI, OUTPUT);
  pinMode(AMARILLOI, OUTPUT);
  pinMode(VERDEI, OUTPUT);
  pinMode(ROJOII, OUTPUT);
  pinMode(AMARILLOII, OUTPUT);
  pinMode(VERDEII, OUTPUT);
  pinMode(ROJOIII, OUTPUT);
  pinMode(AMARILLOIII, OUTPUT);
  pinMode(VERDEIII, OUTPUT);
  pinMode(ROJOVI, OUTPUT);
  pinMode(AMARILLOVI, OUTPUT);
  pinMode(VERDEVI, OUTPUT);
  pinMode(BOTON_PA, INPUT_PULLUP);
  pinMode(BOTON_PB, INPUT_PULLUP);
  pinMode(BOTON_PC, INPUT_PULLUP);
  pinMode(BOTON_PD, INPUT_PULLUP);

  pinMode(BUZZERA, OUTPUT);
  pinMode(BUZZERB, OUTPUT);
  pinMode(BUZZERC, OUTPUT);
  pinMode(BUZZERD, OUTPUT);

  // LEDs peatonales
  pinMode(PE_ROJOa, OUTPUT);
  pinMode(PE_VERDEa, OUTPUT);
  pinMode(PE_ROJOb, OUTPUT);
  pinMode(PE_VERDEb, OUTPUT);
  pinMode(PE_ROJOc, OUTPUT);
  pinMode(PE_VERDEc, OUTPUT);
  pinMode(PE_ROJOd, OUTPUT);
  pinMode(PE_VERDEd, OUTPUT);

  // Inicialización de la matriz LED
  lc.shutdown(0, false);
  lc.setIntensity(0, 4);
  lc.clearDisplay(0);

  // Estado inicial: todo vehicular en rojo, arrancamos en fase peatonal
  todoVehicularRojo();
  peatonalesEnRojo();
  peatonalesEnVerde();
  estado = PEATONAL;
  tiempoInicioFase = millis();
}

// ======================= LOOP NO BLOQUEANTE =======================

void loop() {
  unsigned long ahora = millis();

  switch (estado) {

    case PEATONAL: {
      unsigned long transcurrido = ahora - tiempoInicioFase;

      revisarExtensionPeatonal(transcurrido);
      actualizarCountdownMatrix(transcurrido);
      actualizarBuzzerPeatonal(transcurrido);

      if (transcurrido >= duracionPeatonalActual) {
        peatonalesEnRojo();
        encenderParVerde(indicePar);
        estado = VERDE_VEH;
        tiempoInicioFase = ahora;
      }
      break;
    }

    case VERDE_VEH:
      if (ahora - tiempoInicioFase >= DURACION_VERDE_VEH) {
        apagarVerdePar(indicePar);
        setAmarilloPar(indicePar, true); // amarillo fijo, se enciende una sola vez
        estado = AMARILLO_VEH;
        tiempoInicioFase = ahora;
      }
      break;

    case AMARILLO_VEH:
      // Amarillo FIJO (ya no parpadea): se mantiene encendido por DURACION_AMARILLO
      if (ahora - tiempoInicioFase >= DURACION_AMARILLO) {
        ponerRojoPar(indicePar); // apaga amarillo y pone rojo

        indicePar = (indicePar + 1) % 4;

        peatonalesEnVerde();
        estado = PEATONAL;
        tiempoInicioFase = ahora;
      }
      break;
  }
}
